
import UIKit

class VotingViewController: UITableViewController {

    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var responseColor: UITextField!
    @IBAction func submitAnswer(_ sender: UIButton) {
        
        
    }
    
    

    }

    
    


