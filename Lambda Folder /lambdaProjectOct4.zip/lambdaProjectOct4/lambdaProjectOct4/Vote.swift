import UIKit

class Vote {
    var name = []
    var response = []
}
