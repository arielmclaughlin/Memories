struct Entry: Codable {
    let title: String
    let note: String
}

