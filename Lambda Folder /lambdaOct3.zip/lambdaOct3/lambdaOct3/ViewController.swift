import UIKit

    class PaintingTableViewCell: UIViewController {
        
        @IBOutlet weak var tableView: UITableView!
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            
            tableView.reloadData()
        }
}





