//
//  PaintingTableViewCellDelegate.swift
//  lambdaOct3
//
//  Created by Ariel M. McLaughlin on 10/3/18.
//  Copyright © 2018 Ariel M. McLaughlin. All rights reserved.
//

import Foundation
